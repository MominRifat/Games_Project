package TicTacToe;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
public class Controller 
{

    @FXML private Button btn0;
    @FXML private Button btn1;
    @FXML private Button btn2;
    @FXML private Button btn3;
    @FXML private Button btn4;
    @FXML private Button btn5;
    @FXML private Button btn6;
    @FXML private Button btn7;
    @FXML private Button btn8;
    @FXML private Button newGameButton;
    @FXML private Label titleLabel;

    private boolean xTurn = true;
    private boolean gameOver = false;
    private Button[] buttons;
    @SuppressWarnings("unused")
	@FXML
    public void initialize() 
    {
        buttons = new Button[]{ btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8 };

        for(Button b : buttons) 
        {
            b.setOnAction(e -> handleMove(b));
        }
        newGameButton.setOnAction(e -> resetGame());
    }

    private void handleMove(Button button) 
    {
        if(button.getText().isEmpty() && !gameOver) 
        {
            button.setText(xTurn ? "X" : "O");
            if(checkWin()) 
            {
                titleLabel.setText((xTurn ? "X" : "O") + " Wins!");
                gameOver = true;
                showAlert((xTurn ? "X" : "O") + " Wins!");
            } 
            else if(isDraw()) 
            {
                titleLabel.setText("Draw!");
                gameOver = true;
                showAlert("It's a Draw!");
            } 
            else 
            {
                xTurn = !xTurn;
            }
        }
    }

    private boolean checkWin() 
    {
        String[][] board = new String[3][3];
        for(int i = 0; i < 9; i++) 
        {
            board[i / 3][i % 3] = buttons[i].getText();
        }
        for(int i = 0; i < 3; i++) 
        {
            if(!board[i][0].isEmpty() &&
                board[i][0].equals(board[i][1]) &&
                board[i][1].equals(board[i][2])) return true;

            if(!board[0][i].isEmpty() &&
                board[0][i].equals(board[1][i]) &&
                board[1][i].equals(board[2][i])) return true;
        }

        if(!board[0][0].isEmpty() &&
            board[0][0].equals(board[1][1]) &&
            board[1][1].equals(board[2][2])) return true;

        if(!board[0][2].isEmpty() &&
            board[0][2].equals(board[1][1]) &&
            board[1][1].equals(board[2][0])) return true;

        return false;
    }

    private boolean isDraw() 
    {
        for(Button b : buttons) 
        {
            if (b.getText().isEmpty()) return false;
        }
        return true;
    }

    private void resetGame() 
    {
        for (Button b : buttons) 
        {
            b.setText("");
        }
        xTurn = true;
        gameOver = false;
        titleLabel.setText("Tic Tak Toe");
    }

    private void showAlert(String message) 
    {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Game Over");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
